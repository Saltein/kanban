const sideBar = document.getElementById("sidenav-open");
const sideOpen = document.getElementById("sidenav-button");
const sideClose = document.getElementById("sidenav-close");