let holdTimer;
let angle = 0;
let angleRadians = (angle * Math.PI) / 180;
let speed = 3;

let posX = 200;
let posY = 200;

const message = document.getElementById("sayMessage");
const buttonRight = document.getElementById('right');
const buttonLeft = document.getElementById('left');
const buttonForward = document.getElementById('forward');
const buttonBackward = document.getElementById('backward');
const sprite = document.getElementById("character");


// button RIGHT button RIGHT button RIGHT button RIGHT button RIGHT
function goRight(){
  angle += 3;
  character.style.transform = `rotate(${angle}deg)`;
}
buttonRight.addEventListener('mousedown', () => {
  holdTimer = setInterval(goRight, 10);
});
buttonRight.addEventListener('mouseup', () => {
  clearInterval(holdTimer);
  
});
buttonRight.addEventListener('mouseout', () => {
  clearInterval(holdTimer);
  angleRadians = (angle * Math.PI) / 180;
});
// button RIGHT button RIGHT button RIGHT button RIGHT button RIGHT



// button LEFT button LEFT button LEFT button LEFT button LEFT
function goLeft(){
  angle -= 3;
  character.style.transform = `rotate(${angle}deg)`;
}
buttonLeft.addEventListener('mousedown', () => {
  holdTimer = setInterval(goLeft, 10);
});
buttonLeft.addEventListener('mouseup', () => {
  clearInterval(holdTimer);
});
buttonLeft.addEventListener('mouseout', () => {
  clearInterval(holdTimer);
  angleRadians = (angle * Math.PI) / 180;
});
// button LEFT button LEFT button LEFT button LEFT button LEFT




// button FORWARD button FORWARD button FORWARD button FORWARD
function goForward(){
  posX += speed * Math.sin(angleRadians);
  posY -= speed * Math.cos(angleRadians);
  character.style.top = posY + "px";
  character.style.left = posX + "px";
}
buttonForward.addEventListener('mousedown', () => {
  holdTimer = setInterval(goForward, 10);
});
buttonForward.addEventListener('mouseup', () => {
  clearInterval(holdTimer);
});
buttonForward.addEventListener('mouseout', () => {
  clearInterval(holdTimer);
  angleRadians = (angle * Math.PI) / 180;
});
// button FORWARD button FORWARD button FORWARD button FORWARD




// button BACKWARD button BACKWARD button BACKWARD button BACKWARD
function goBackward(){
  posX -= speed * Math.sin(angleRadians);
  posY += speed * Math.cos(angleRadians);
  character.style.top = posY + "px";
  character.style.left = posX + "px";
}
buttonBackward.addEventListener('mousedown', () => {
  holdTimer = setInterval(goBackward, 10);
});
buttonBackward.addEventListener('mouseup', () => {
  clearInterval(holdTimer);
});
buttonBackward.addEventListener('mouseout', () => {
  clearInterval(holdTimer);
  angleRadians = (angle * Math.PI) / 180;
});
// button BACKWARD button BACKWARD button BACKWARD button BACKWARD



// button SAY button SAY button SAY button SAY button SAY
function goSay(){
  message.style.top = posY - 40 + "px";
  message.style.left = posX + 55 + "px";
  message.style.display = "flex";
  setTimeout(function() {
    message.style.display = "none";
  }, 1500)
}
// button SAY button SAY button SAY button SAY button SAY


// управление с помощью wasd херово работает


// window.addEventListener("keydown", function(e){
//   switch(e.key){
//     case "w":
//       holdTimer = setInterval(goForward, 10);
//       break;
//     case "s":
//       holdTimer = setInterval(goBackward, 10);
//       break;
//     case "a":
//       holdTimer = setInterval(goLeft, 10);
//       break;
//     case "d":
//       holdTimer = setInterval(goRight, 10);
//       break;
//   }
// });

// window.addEventListener("keyup", function(e){
//   switch(e.key){
//     case "w":
//     case "s":
//     case "a":
//     case "d":
//       clearInterval(holdTimer);
//       break;
//   }
// });

